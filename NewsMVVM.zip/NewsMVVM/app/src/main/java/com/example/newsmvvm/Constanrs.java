package com.example.newsmvvm;

public class Constanrs {

    public static final String API_KEY="c26a5b7fce024a58b55d2bbee6b5b836";
    public static final String LANGuAGE="en";

}
